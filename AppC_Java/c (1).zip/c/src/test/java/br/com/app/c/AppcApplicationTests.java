package br.com.app.c;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppcApplicationTests {

	@Test
	void contextLoads() {
	}

}
