package br.com.app.c;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppcApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppcApplication.class, args);
	}

}
